﻿// pch.cpp: plik źródłowy odpowiadający wstępnie skompilowanemu nagłówkowi

#include "pch.h"

// W przypadku korzystania ze wstępnie skompilowanych nagłówków ten plik źródłowy jest niezbędny, aby kompilacja powiodła się.
